print("Hello World")

name = "Nicholas Ung"
print("Hello",name)

print("Hello " + name)

num = 22
print("Hello",num)

# print("Hello " + num)

print("Hello " + str(num))

food1 = "steak"
food2 = "eggs"
print("I love to eat {} and {}.".format(food1,food2))

print(f"I love to eat {food1} and {food2}.")